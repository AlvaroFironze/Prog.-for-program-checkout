from distutils.core import setup

setup(
    name='LogServer',
    version='0.0.1',
    author='Stahov Maxim & Milenteva Anastasia',
    author_email='mdstakhov@edu.hse.ru',
    packages=['LogServer'],
    package_dir={'LogServer':""},
    url='https://github.com/AlvaroFironze/Prog.-for-program-checkout/',
    description='Program for program checkout',

)
